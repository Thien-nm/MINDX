
// let x;
// let y;
// x = 3;
// y = 4;
// x += x; //x= 3+3
// x += y; //x= 3+3+4
// y += y; //y= 3+3+4+4
// y += x; //y= 3+3+4+4+4
// console.log(x);
// console.log(y);


let x;
x = 62680/8;
console.log(x);

//Túi thứ nhất đựng 18kg gạo, gấp 3 lần túi thứ hai. 
//Hỏi phải lấy ở túi thứ nhất bao nhiêu kg gạo đổ sang túi thứ hai để số gạo ở hai túi bằng nhau?

let t_1 = 18 ;
let t_2 = t_1/3;
let sogaocantim ;
sogaocantim = (18 - t_2)/2;
console.log("sogaocantim",sogaocantim);

//Tính chu vi hình tứ giác ABCD, biết cạnh AB =16cm, BC = 20cm, cạnh CD bằng nửa tổng AB và BC. 
//Cạnh AD gấp đôi hiệu của AB và BC.
//https://git-scm.com/downloads

let AB = 16;
let BC = 20;
let CD = (AB + BC)/2;
let AD = (BC - AB)*2;
let chuvitugiac = (AB + BC + CD + AD);
console.log("chuvitugiac", chuvitugiac);




